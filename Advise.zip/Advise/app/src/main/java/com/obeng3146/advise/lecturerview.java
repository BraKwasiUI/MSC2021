package com.obeng3146.advise;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class lecturerview extends AppCompatActivity{
  private TextView secret;

    private RecyclerView mAdList;

    private DatabaseReference mDatabase;
    private Query mDatabaseCompanies;

    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;

    Query query;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lecturerview);
      //  myDb=new DataBaseHelper(this);



        //carrying the value
        secret=(TextView)findViewById(R.id.userid) ;
        Intent stextview= getIntent();
        String secrettxt= stextview.getStringExtra("Username");
        secret.setText(secrettxt);
        mAuth=FirebaseAuth.getInstance();
        //checks if user is logged in else it redirects
//        mAuthListener=new FirebaseAuth.AuthStateListener() {
//            @Override
//            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
//                if(firebaseAuth.getCurrentUser()==null){
//                    Intent loginIn=new Intent(lecturerview.this,MainActivity.class);
//                    loginIn.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                    startActivity(loginIn);
//                }
//            }
//        };
        //final String user_id=mAuth.getCurrentUser().getUid();
        mDatabase= FirebaseDatabase.getInstance().getReference().child("Advisors");//.child(secrettxt);
        mDatabaseCompanies= FirebaseDatabase.getInstance().getReference().child("Student");//.child("/*");//.orderByChild(secrettxt);


        mDatabaseCompanies.keepSynced(true);
        mDatabase.keepSynced(true);

        query=mDatabaseCompanies.orderByChild("advisor").equalTo(secrettxt);
        mAdList=(RecyclerView) findViewById(R.id.ad_list);
        mAdList.setHasFixedSize(true);
        mAdList.setLayoutManager(new LinearLayoutManager(this));

        //checkUserExist();
    }

    @Override
    protected void onStart() {
        super.onStart();



        //mAuth.addAuthStateListener(mAuthListener);

        FirebaseRecyclerAdapter<Student, AdsViewHolder> firebaseRecyclerAdapter=new FirebaseRecyclerAdapter<Student, AdsViewHolder>(
                Student.class,R.layout.ad_row,AdsViewHolder.class,query) {
            @Override
            protected void populateViewHolder(AdsViewHolder viewHolder, Student model, int position) {
                final String ad_key=getRef(position).getKey();
//                final String user_id=mAuth.getCurrentUser().getUid();

                viewHolder.setTitle((model.getThesecret()));
                viewHolder.setTitle((ad_key));
                //viewHolder.setDesc((model.getDesc()));
                //viewHolder.setImage(getApplicationContext(), (model.getImage()));
                //viewHolder.setUsername((model.getUsername()));

                viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(lecturerview.this,ad_key,Toast.LENGTH_SHORT).show();

                        Intent singleStudIntent=new Intent(lecturerview.this,Specifics.class);
                        singleStudIntent.putExtra("studdet_id",ad_key);
                        startActivity(singleStudIntent);
                    }
                });
            }
        };

        mAdList.setAdapter(firebaseRecyclerAdapter);
    }

//    private void checkUserExist() {
//
//        if(mAuth.getCurrentUser()!=null){
//            final String user_id=mAuth.getCurrentUser().getUid();
//
//            mDatabaseCompanies.addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(DataSnapshot dataSnapshot) {
//                    if(!dataSnapshot.hasChild(user_id)){
//                        Intent mainInent=new Intent(lecturerview.this,advisorLogin.class);
//                        mainInent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                        startActivity(mainInent);
//                    }
//                }
//
//                @Override
//                public void onCancelled(DatabaseError databaseError) {
//
//                }
//            });
//        }
//    }

    public static class AdsViewHolder extends RecyclerView.ViewHolder{
        View mView;

        public AdsViewHolder(View itemView) {
            super(itemView);

            mView=itemView;
        }

        public void setTitle(String title){
            TextView ad_title=(TextView) itemView.findViewById(R.id.ad_title);
            ad_title.setText(title);
        }

//        public void setDesc(String desc){
//            TextView ad_desc=(TextView) itemView.findViewById(R.id.ad_desc);
//            ad_desc.setText(desc);
//        }
//
//        public void setUsername(String username){
//            TextView ad_username=(TextView) itemView.findViewById(R.id.ad_username);
//            ad_username.setText(username);
//        }

       /* public void setImage(final Context context, final String image){
            final ImageView ad_image=(ImageView) itemView.findViewById(R.id.ad_image);
            Picasso.with(context).load(image).networkPolicy(NetworkPolicy.OFFLINE).into(ad_image, new Callback() {
                @Override
                public void onSuccess() {

                }

                @Override
                public void onError() {
                    Picasso.with(context).load(image).into(ad_image);
                }
            });
        }*/
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
//        if (item.getItemId()==R.id.action_add){
//            startActivity(new Intent(Write.this,Posts.class));
//        }
//
//        if (item.getItemId()==R.id.action_logout){
//            logout();
//        }

        return super.onOptionsItemSelected(item);
    }

    private void logout() {
        mAuth.signOut();
    }
}


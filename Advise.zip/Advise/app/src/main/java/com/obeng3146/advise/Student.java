package com.obeng3146.advise;

/**
 * Created by Oheneba k.b on 12/27/2017.
 */

public class Student {

    private String thesecret;
    private String name;
    private String studentmail;
    private String advisor;
    private String semester;
    private String academicyear;
    private String program;
    private String studphone;
    private String  guardphone;
    private String guardemail;
    private String ungradedcourses;
    private String graderesolution;
    private String courseproblem;
    private String otherproblems;
    private String scholar;

    public Student() {


    }

    public Student(String thesecret,String name, String studentmail, String advisor, String semester, String academicyear, String program, String studphone, String guardphone, String guardemail, String ungradedcourses, String graderesolution, String courseproblem, String otherproblems,String scholar) {
        this.thesecret=thesecret;
        this.name = name;
        this.studentmail = studentmail;
        this.advisor = advisor;
        this.semester = semester;
        this.academicyear = academicyear;
        this.program = program;
        this.studphone = studphone;
        this.guardphone = guardphone;
        this.guardemail = guardemail;
        this.ungradedcourses = ungradedcourses;
        this.graderesolution = graderesolution;
        this.courseproblem = courseproblem;
        this.otherproblems = otherproblems;
        this.scholar = scholar;
    }

    public String getScholar() {
        return scholar;
    }

    public void setScholar(String scholar) {
        this.scholar = scholar;
    }

    public String getThesecret() {
        return thesecret;
    }

    public void setThesecret(String thesecret) {
        this.name = thesecret;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStudentmail() {
        return studentmail;
    }

    public void setStudentmail(String studentmail) {
        this.studentmail = studentmail;
    }

    public String getAdvisor() {
        return advisor;
    }

    public void setAdvisor(String advisor) {
        this.advisor = advisor;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getAcademicyear() {
        return academicyear;
    }

    public void setAcademicyear(String academicyear) {
        this.academicyear = academicyear;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public String getStudphone() {
        return studphone;
    }

    public void setStudphone(String studphone) {
        this.studphone = studphone;
    }

    public String getGuardphone() {
        return guardphone;
    }

    public void setGuardphone(String guardphone) {
        this.guardphone = guardphone;
    }

    public String getGuardemail() {
        return guardemail;
    }

    public void setGuardemail(String guardemail) {
        this.guardemail = guardemail;
    }

    public String getUngradedcourses() {
        return ungradedcourses;
    }

    public void setUngradedcourses(String ungradedcourses) {
        this.ungradedcourses = ungradedcourses;
    }

    public String getGraderesolution() {
        return graderesolution;
    }

    public void setGraderesolution(String graderesolution) {
        this.graderesolution = graderesolution;
    }

    public String getCourseproblem() {
        return courseproblem;
    }

    public void setCourseproblem(String courseproblem) {
        this.courseproblem = courseproblem;
    }

    public String getOtherproblems() {
        return otherproblems;
    }

    public void setOtherproblems(String otherproblems) {
        this.otherproblems = otherproblems;
    }
}





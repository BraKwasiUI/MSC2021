package com.obeng3146.advise;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Doublelogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doublelogin);
        final AlertDialog.Builder builder=new AlertDialog.Builder(Doublelogin.this);
        builder.setMessage("Sorry! Form has already been filled. Contact the System Administrator for any changes Thank you for using Advise. Your advisor will get back to you soon.");
        builder.setCancelable(true);
//out
        builder.setNegativeButton("", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });


        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // finish();
                //System.exit(0);
                Intent intent=new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                startActivity(intent);

                //Kill app in the background
                android.os.Process.killProcess(android.os.Process.myPid());
            }//
        });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();

    }
}

package com.obeng3146.advise;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class admin extends AppCompatActivity {

    DataBaseHelper myDb;// Setting the instance of the database in the activity_main java class
    private Button Addlec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        myDb=new DataBaseHelper(this);

        Addlec=(Button)findViewById(R.id.addBtn);
        Addlec.setOnClickListener(new View.OnClickListener() {//inner classs listener for the button
            @Override
            public void onClick(View v) {
                switch(v.getId()){// using switch to get the id's
                    case R.id.addBtn:
                        ShowDialogUpdate(admin.this);// shows the dialogue in the admin page

                break;
            }}
        });


    }



//This is for adding the lecturer
    public void ShowDialogUpdate(Activity activity){// this is the dialoque alert codes
        final Dialog dialog= new Dialog(activity);
        dialog.setContentView(R.layout.addlecturer);

        int width=(int)(activity.getResources().getDisplayMetrics().widthPixels*0.95);//initializing the width for the dialog alert
        int height=(int)(activity.getResources().getDisplayMetrics().heightPixels*0.9);//initializing the heigth for the diaog alert

        //Finding the ID from the signup java since we are using the popup:NB do this in the mainactivity
        Button btnadding=(Button) dialog.findViewById(R.id.btnAdd);
        final EditText Nametxt=(EditText) dialog.findViewById(R.id.enterSName);
        final EditText Useridtxt=(EditText) dialog.findViewById(R.id.enterSID);
        final EditText passwordtxt=(EditText) dialog.findViewById(R.id.enterLPassword);
        final EditText Confirmpasstxt=(EditText) dialog.findViewById(R.id.confirmLPass);


        btnadding.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Getting the input values from the User
                String name = Nametxt.getText().toString().trim();
                String Password = passwordtxt.getText().toString().trim();
                String Confirm = Confirmpasstxt.getText().toString().trim();

                if (!Password.equals(Confirm)) {// This compares the password with the conform password to see wether it is valid
                    Toast.makeText(getApplicationContext(), "Passwords Don't match", Toast.LENGTH_SHORT).show();//shows Toast

                } else if (!name.isEmpty() && !Password.isEmpty()) {//This checks that if all the textboxes are not empty

                    myDb.insertlecturer(name,Password);/*This code does the insertion into the database
                                          when all the the textboxes are filled
                                          */

                    Toast.makeText(getApplicationContext(), "Lecturer Sucessfully Added", Toast.LENGTH_SHORT).show();
                } else {//This shows that all input are required when none is filled and the user wants to continue the action

                    Toast.makeText(getApplicationContext(), "Inputs Required", Toast.LENGTH_SHORT).show();
                }

            }
        });
        dialog.getWindow().setLayout(width,height);//setting the height and the width of the dialog alert
        dialog.show();//This code displays the Dialog Alert
    }
}

package com.obeng3146.advise;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Specifics extends AppCompatActivity implements View.OnClickListener {

    private TextView name,email,aca,sem,program,others,Snumber,Gnumber,Gmail,Ungraded,Resolution,CCheck,school;
    private Button back,send,download;

    private String mKey=null;
    private DatabaseReference mDatabaseStudies;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specifics);

        back=(Button) findViewById(R.id.btnBack);
        send=(Button) findViewById(R.id.btnSendEmail);
        download=(Button) findViewById(R.id.btnView);

        name=(TextView) findViewById(R.id.txtName);
       email=(TextView) findViewById(R.id.txtEmail);
        sem=(TextView) findViewById(R.id.txtSem);
        aca=(TextView) findViewById(R.id.txtAca);
        program=(TextView) findViewById(R.id.txtProgram);
        others=(TextView) findViewById(R.id.txtOther);
        Snumber=(TextView) findViewById(R.id.txtSPhone);
        Gmail=(TextView) findViewById(R.id.txtGmail);
        Gnumber=(TextView) findViewById(R.id.txtGphone);
        Ungraded=(TextView) findViewById(R.id.txtUngrade);
        Resolution=(TextView) findViewById(R.id.txtRes);
        CCheck=(TextView) findViewById(R.id.txtCourseP);
        school=(TextView) findViewById(R.id.url);

        mDatabaseStudies= FirebaseDatabase.getInstance().getReference().child("Student");
        mKey=getIntent().getExtras().getString("studdet_id");

        mDatabaseStudies.child(mKey).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String stud_name= (String) dataSnapshot.child("name").getValue();
                String stud_email= (String) dataSnapshot.child("studentmail").getValue();
                String stud_aca= (String) dataSnapshot.child("academicyear").getValue();
                String stud_sem= (String) dataSnapshot.child("semester").getValue();
                String stud_program= (String) dataSnapshot.child("program").getValue();
                String stud_number= (String)dataSnapshot.child("studphone").getValue();
                String g_phone= (String)dataSnapshot.child("guardphone").getValue();
                String g_mail= (String) dataSnapshot.child("guardemail").getValue();
                String stud_Ungraded= (String) dataSnapshot.child("ungradedcourses").getValue();
                String stud_Resolution= (String) dataSnapshot.child("graderesolution").getValue();
                String stud_CourseC= (String) dataSnapshot.child("courseproblem").getValue();
                String stud_otherP= (String) dataSnapshot.child("otherproblems").getValue();
                String stud_scholar= (String) dataSnapshot.child("scholar").getValue();

                name.setText(stud_name);
                email.setText(stud_email);
                aca.setText(stud_aca);
                sem.setText(stud_sem);
                program.setText(stud_program);
                Snumber.setText(stud_number);
                Gnumber.setText(g_phone);
                Gmail.setText(g_mail);
                Ungraded.setText(stud_Ungraded);
                CCheck.setText(stud_CourseC);
                Resolution.setText(stud_Resolution);
                others.setText(stud_otherP);
                school.setText(stud_scholar);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        back.setOnClickListener(this);
        send.setOnClickListener(this);
        Snumber.setOnClickListener(this);
        Gnumber.setOnClickListener(this);
        download.setOnClickListener(this);
    }

    private void shareMessage() {
        // create the URL representing the search
        String emailText =email.getText().toString();


        // create Intent to share urlString
        Intent shareIntent = new Intent();
        shareIntent.setAction(Intent.ACTION_SEND);
        shareIntent.setData(Uri.parse("email"));
        shareIntent.putExtra(Intent.EXTRA_EMAIL,new String[]{emailText});
        shareIntent.putExtra(Intent.EXTRA_SUBJECT,getString(R.string.email_subject));
        //shareIntent.putExtra(Intent.EXTRA_TEXT, getString(R.string.headeer,emailText));
        shareIntent.setType("text/plain");


        // display apps that can share plain text
        startActivity(Intent.createChooser(shareIntent, getString(R.string.share_msg)));


    }

    private void callstudent(){

        String studcallText= Snumber.getText().toString();

        //creating the Intent
        Intent callintent= new Intent(Intent.ACTION_DIAL);
        if(studcallText.trim().isEmpty()){
            callintent.setData(Uri.parse("tel: 7788994455"));
        }
        else{
            callintent.setData(Uri.parse("tel:"+studcallText));
        }
        startActivity(callintent);
    }

    private void callparent(){
        String parentcalltext=Gnumber.getText().toString();

        //creating the Intent
        Intent parentintent= new Intent(Intent.ACTION_DIAL);
        if(parentcalltext.trim().isEmpty()){
            parentintent.setData(Uri.parse("tel: 7788994455"));
        }
        else {
            parentintent.setData(Uri.parse("tel:"+parentcalltext));
        }
        startActivity(parentintent);
    }




    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnBack:
                finish();
                break;
            case R.id.btnSendEmail:
                shareMessage();
                break;

            case R.id.txtSPhone:
                callstudent();
                break;

            case R.id.txtGphone:
                callparent();
                break;

            case R.id.btnView:
                viewdoc();
                break;
        }
    }

    private void viewdoc() {
        String sch=school.getText().toString();
        Uri url=Uri.parse(sch);

        DownloadManager downloadManager= (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Request request=new DownloadManager.Request(url);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        downloadManager.enqueue(request);
    }
}

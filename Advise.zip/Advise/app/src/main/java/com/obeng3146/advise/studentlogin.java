package com.obeng3146.advise;

import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class studentlogin extends AppCompatActivity  implements View.OnClickListener{

    private int split;
    private TextView signupLink;
    private Button logmein;
    private EditText username,pass;

    //This is for firebase
    private FirebaseDatabase database;
    private DatabaseReference myref,myref2;
    private FirebaseAuth myauth;
    private FirebaseAuth.AuthStateListener  myauthlistener;



    DataBaseHelper myDb;// Setting the instance of the database in the activity_main java class
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studentlogin);

        myDb=new DataBaseHelper(this);

        signupLink=(TextView) findViewById(R.id.signUpOtion);
        logmein=(Button) findViewById(R.id.login);

        logmein.setOnClickListener(this);
        signupLink.setOnClickListener(this);


        //referecing the firebase=============================================================================================
        database=FirebaseDatabase.getInstance();
        myref=database.getReference().child("Users");

        myref2 = database.getReference().child("Student");

        myauth=FirebaseAuth.getInstance();
        myauthlistener= new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {



            }
        };
    }
//====================================================================================================================================
    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.signUpOtion:
                showDialogUpdate(studentlogin.this);
                break;

            case R.id.login:
                username=(EditText)findViewById(R.id.enterSName);
                   pass=(EditText)findViewById(R.id.password);

                signin(username.getText().toString().trim(),pass.getText().toString().trim());



                //this si for the login button to check whether the Username and the password entered is correct
//                 username=(EditText)findViewById(R.id.enterSName);
//                pass=(EditText)findViewById(R.id.password);
//
//                String userName= username.getText().toString();//getting the username and passing ti as string
//                String pazz= pass.getText().toString();//getting the password and passing it as string
//
//
//                String password= myDb.searchpass(userName);
//                //checking if the password entered equals the one typed by the user
//                if (pazz.equals(password)) {
//                    Intent i = new Intent(studentlogin.this, studentform.class);
//                    i.putExtra("Username", userName);
//                    startActivity(i);
//                } else {
//                   Toast temp=Toast.makeText(studentlogin.this,"Passwords don't match",Toast.LENGTH_SHORT);
//                    temp.show();
//                }
                break;
        }
    }



//This is the firebase codes for validating signup============================================================================
    private void signin(final String username, final String password) {
        myref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.child(username).exists()){
                    if(!username.isEmpty()){
                        User gettinguser = dataSnapshot.child(username).getValue(User.class);
                        if(gettinguser.getPassword().equals(password)){
                            Intent i = new Intent(studentlogin.this, studentform.class);
                            i.putExtra("Username",username);
                              startActivity(i);
                            finish();
                        }
                        else{
                            Toast.makeText(studentlogin.this,"Wrong Password",Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(studentlogin.this,"Enter Valid Student ID",Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(studentlogin.this,"Student ID doesn't exist",Toast.LENGTH_SHORT).show();
                }

                }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
//=============================================================================================================================

    private void showDialogUpdate(Activity activity)
    {
        final Dialog dialog= new Dialog(activity);//calling the dialog alert
        dialog.setContentView(R.layout.signup);//getting the dialog alert layout from the targeted xml

        int width=(int)(activity.getResources().getDisplayMetrics().widthPixels*0.95);//initializing the width for the dialog alert
        int height=(int)(activity.getResources().getDisplayMetrics().heightPixels*0.9);//initializing the heigth for the diaog alert

        //Finding the ID from the signup java since we are using the popup:NB do this in the mainactivity
        Button btnSignUp=(Button) dialog.findViewById(R.id.SignUP);
        final EditText Useridtxt=(EditText) dialog.findViewById(R.id.enterSID);
        final EditText GPatxt=(EditText) dialog.findViewById(R.id.gpatxt);
        final EditText passwordtxt=(EditText) dialog.findViewById(R.id.enterLPassword);
        final EditText Confirmpasstxt=(EditText) dialog.findViewById(R.id.confirmLPass);


        btnSignUp.setOnClickListener(new View.OnClickListener() {// the button event listener for the signup button
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.SignUP:
                        try {
                            //Getting the input values from the User
                            final String Userid = Useridtxt.getText().toString().trim();
                            final Double GPA = Double.valueOf(GPatxt.getText().toString());
                            String Password = passwordtxt.getText().toString().trim();
                            String Confirm = Confirmpasstxt.getText().toString().trim();


                            if (!Password.equals(Confirm)) {// This compares the password with the conform password to see wether it is valid
                                Toast.makeText(getApplicationContext(), "Passwords Don't match", Toast.LENGTH_SHORT).show();//shows Toast
//FIREBASE CODES
                            } else if (!Userid.isEmpty() && !Password.isEmpty()) {//This checks that if all the textboxes are not empty

                                final User theuser= new User(Userid,GPA,Password);

                                myref.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot) {
                                        if(dataSnapshot.child(theuser.getStudentid()).exists()){
                                            Toast.makeText(studentlogin.this,"User already exist",Toast.LENGTH_SHORT).show();
                                        }
                                       else if(GPA>4.0){
                                            Toast.makeText(studentlogin.this,"Please enter the appropriate GPA",Toast.LENGTH_SHORT).show();
                                        }
                                        else{
                                            myref.child(theuser.getStudentid()).setValue(theuser);



                                            //fist class
                                             if (GPA >3.59 && GPA==4.0) {
                                                firstclass();
                                            }
                                            //second lower
                                            else if(GPA > 2.49 && GPA<3.25) {
                                                SecondLower();
                                            }
                                            //second upper
                                            else if(GPA >3.24 && GPA <3.60){
                                                secondupper();
                                            }
                                            //3rd class
                                            else if(GPA >2.0 && GPA <2.50){
                                                thirdclass();
                                            }


                                            Intent i = new Intent(studentlogin.this, studentform.class);
                                            i.putExtra("Username",Userid);
                                            startActivity(i);
                                            Toast.makeText(studentlogin.this,"User registeration Sucessfull",Toast.LENGTH_SHORT).show();
                                        }
                                    }

                                    @Override
                                    public void onCancelled(DatabaseError databaseError) {

                                    }
                                });

                               /* myDb.insertsignup( Userid.trim(), GPA, Password.trim(), "S");/*This code does the insertion into the database
                                          when all the the textboxes are filled

                                    Toast.makeText(getApplicationContext(), "Signup Sucessfully", Toast.LENGTH_SHORT).show();
*/
                            } else {//This shows that all input are required when none is filled and the user wants to continue the action
                                Toast.makeText(getApplicationContext(), "Inputs Required", Toast.LENGTH_SHORT).show();
                            }
                        }catch (NumberFormatException e){// This exception handler handles the gpa
                            GPatxt.setText("");
                        }

                        break;
                }
            }
        });

        dialog.getWindow().setLayout(width,height);//setting the height and the width of the dialog alert
        dialog.show();//This code displays the Dialog Alert
    }


   public void SecondLower(){

       //To set large icon notifcation
       Bitmap icon1= BitmapFactory.decodeResource(getResources(),R.drawable.logo);
       //Assign BigText style notification
       NotificationCompat.BigTextStyle bigText= new NotificationCompat.BigTextStyle();
       bigText.bigText("Hi! you re a second class lower student. " +
               "Sit up Your performance is not encouraging. Spend more time on academic work and take out activities that hinder academic progress" +
               "You can do better. Sit up I believe in you. There is more you can do.");
       bigText.setBigContentTitle("System Advise");
       bigText.setSummaryText("By:System Intelligence");
       //build notification
       NotificationCompat.Builder mBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(this)
               .setSmallIcon(R.drawable.user2)
               .setContentTitle("System Advise")
               .setContentText("System Advise")
               .setLargeIcon(icon1)
               .setStyle(bigText);
       Uri alarmsound= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
       mBuilder.setSound(alarmsound);
       mBuilder.setVibrate(new long[]{1000,1000,1000});

       NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
       notificationManager.notify(0, mBuilder.build());

   }

    public void firstclass(){

        //To set large icon notifcation
        Bitmap icon1= BitmapFactory.decodeResource(getResources(),R.drawable.logo);
        //Assign BigText style notification
        NotificationCompat.BigTextStyle bigText= new NotificationCompat.BigTextStyle();
        bigText.bigText("Hi! You are a first class student." +
                "Keep up the good work. Stay focused and sure not to get distracted at any point. " +
                "Strive to be the best among the first and know that there's no limit to any level of greatness that can be achieved.");//This is where the main context is
        bigText.setBigContentTitle("System Advise");
        bigText.setSummaryText("By:System Intelligence");
        //build notification
        NotificationCompat.Builder mBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.user2)
                .setContentTitle("System Advise")
                .setContentText("System Advise")
                .setLargeIcon(icon1)
                .setStyle(bigText);
        Uri alarmsound= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        mBuilder.setSound(alarmsound);
        mBuilder.setVibrate(new long[]{1000,1000,1000});

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(0, mBuilder.build());

    }

    public void secondupper(){

        //To set large icon notifcation
        Bitmap icon1= BitmapFactory.decodeResource(getResources(),R.drawable.logo);
        //Assign BigText style notification
        NotificationCompat.BigTextStyle bigText= new NotificationCompat.BigTextStyle();
        bigText.bigText("Hi! You are a second class upper student. Keep up the good work, stay focused. Study hard and always believe you can do better" +
                "Spend less time on extra curricular activities if they tend to affect your academic performance." +
                "Sit up! You are a promising student.");
        bigText.setBigContentTitle("System Advise");
        bigText.setSummaryText("By:System Intelligence");
        //build notification
        NotificationCompat.Builder mBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.user2)
                .setContentTitle("System Advise")
                .setContentText("System Advise")
                .setLargeIcon(icon1)
                .setStyle(bigText);
        Uri alarmsound= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        mBuilder.setSound(alarmsound);
        mBuilder.setVibrate(new long[]{1000,1000,1000});

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(0, mBuilder.build());

    }

    public void thirdclass(){

        //To set large icon notifcation
        Bitmap icon1= BitmapFactory.decodeResource(getResources(),R.drawable.logo);
        //Assign BigText style notification
        NotificationCompat.BigTextStyle bigText= new NotificationCompat.BigTextStyle();
        bigText.bigText("Hi! You are a third class student. Your Performance is not encouraging at all" +
                "Seek academic help from fellow students if possible. Sit up I believe you can do better." +
                "More grease to your elbows");
        bigText.setBigContentTitle("System Advise");
        bigText.setSummaryText("By:System Intelligence");
        //build notification
        NotificationCompat.Builder mBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.user2)
                .setContentTitle("System Advise")
                .setContentText("System Advise")
                .setLargeIcon(icon1)
                .setStyle(bigText);
        Uri alarmsound= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                mBuilder.setSound(alarmsound);
                 mBuilder.setVibrate(new long[]{1000,1000,1000});

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(0, mBuilder.build());

    }

}

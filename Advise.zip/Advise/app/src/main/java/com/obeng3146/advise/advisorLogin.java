package com.obeng3146.advise;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class advisorLogin extends AppCompatActivity implements View.OnClickListener {
   private EditText userid;
    private EditText pass;
    private Button logiin;

    //This is for firebase
    private FirebaseDatabase database;
    private DatabaseReference myref;
    private FirebaseAuth myauth;
    private FirebaseAuth.AuthStateListener  myauthlistener;

   // DataBaseHelper myDb;// Setting the instance of the database in the activity_main java class
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advisor_login);

      //  myDb=new DataBaseHelper(this);

        logiin=(Button)findViewById(R.id.login);
           logiin.setOnClickListener(this);

        //referecing the firebase=============================================================================================
        database=FirebaseDatabase.getInstance();
        myref=database.getReference().child("Advisors");

        userid=(EditText)findViewById(R.id.enterSName);
        pass=(EditText)findViewById(R.id.password);

        myauth=FirebaseAuth.getInstance();
        myauthlistener= new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {



            }
        };
    }

    @Override
    public void onClick(View v) {
         switch(v.getId()){
             case R.id.login:
                 signin(userid.getText().toString().trim(),pass.getText().toString().trim());
         }
    }

    private void signin(final String username, final String password) {
        myref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.child(username).exists()){
                    if(!username.isEmpty()){
                        Advisors gettingadvisor = dataSnapshot.child(username).getValue(Advisors.class);
                        if(gettingadvisor.getPassword().equals(password)){
                            Intent i = new Intent(advisorLogin.this, lecturerview.class);
                            i.putExtra("Username",username);
                            startActivity(i);
                            finish();
                        }
                        else{
                            Toast.makeText(advisorLogin.this,"Wrong Password",Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(advisorLogin.this,"Enter Valid Username",Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(advisorLogin.this,"AdvisorName doesn't exist",Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }


}
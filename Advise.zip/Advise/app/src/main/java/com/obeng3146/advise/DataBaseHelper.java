package com.obeng3146.advise;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteStatement;

import java.security.GuardedObject;

import static android.os.Build.ID;
import static java.sql.Types.FLOAT;

/**
 * Created by Oheneba k.b on 11/6/2017.
 */

public class DataBaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Advisement.db";//Defining the database name
    public static final String TABLE_NAME = "login_table";// Defining the database table
    public static final String SecondTable = "Lect_login";
    public static final String ThirdTable = "Stud_Details";


    //Defining the table columns for login Table
    public static final String COL_1 = "ID";
    public static final String COL_2 = "Userid";
    public static final String COL_3 = "GPA";
    public static final String COL_4 = "Password";
    public static final String COL_5 = "Usertype";



    //Defining the table columns for the lecturer login
    public static final String lectid = "ID";
    public static final String namecol = "Name";
    public static final String passwordcol = "Password";


    //Defining the table columns for student Details table
    public static final String tableid="ID";
    public static final String stuname="Name";
    public static final String mail="Mail";
    public static final String advisor="Advisor";
    public static final String semester="Semester";
    public static final String acayear="Acayear";
    public static final String program="Program";
    public static final String stuphone="Stuphone";
    public static final String guardphone="Guardphone";
    public static final String guardemail="Guardemail";
    public static final String ungraded="ungradedcourses";
    public static final String resolution="coursesresolu";
    public static final String probcourses="problemcourses";
    public static final String otherprob="Otherprob";



    //Creating a default constructor for the database
    public DataBaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    //Modifying the context
    public DataBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
        SQLiteDatabase db = this.getReadableDatabase();// this code creates the database so it can be accessed in the other activities
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
//Writing the Query to create the table
        db.execSQL("CREATE TABLE " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, Userid Text Not Null, GPA DOUBLE Not Null,Password Text Not Null,Usertype Text Not Null)");
        db.execSQL("CREATE TABLE " + SecondTable + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, Name Text Not Null,Password Text Not Null)");
        db.execSQL("CREATE TABLE " +ThirdTable+ "(ID INTEGER PRIMARY KEY AUTOINCREMENT,Name Text Not Null, Mail Text Not Null,Advisor Text Not Null,Semester Text Not Null,Program Text Not Null,Stuphone Text Not Null,Guardphone Text Not Null,Guardemail Text Not Null,ungradedcourses Text Null,coursesresolu Text Null,problemcourses Text Null,Otherprob Text Null)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //This code drops the table if the table already exist
        db.execSQL("Drop TABLE IF EXISTS" + TABLE_NAME);
        db.execSQL("Drop TABLE IF EXISTS" + SecondTable);
        db.execSQL("Drop TABLE IF EXISTS" + ThirdTable);
    }

//===============================================================================================Inserting signup for student
    public void insertsignup( String Userid, Double GPA, String Password, String Usertype) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentvalues = new ContentValues();
        contentvalues.put(COL_2, Userid);
        contentvalues.put(COL_3, GPA);
        contentvalues.put(COL_4, Password);
        contentvalues.put(COL_5, Usertype);
        db.insert(TABLE_NAME, null, contentvalues);
        db.close();
    }
//===============================================================================================Inserting lecturer details
    public void insertlecturer(String Name,String Password){
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues values= new ContentValues();
        values.put(namecol, Name);
        values.put(passwordcol, Password);
        db.insert(SecondTable,null,values);
        db.close();
    }

    //===================================================================Inserting student Details
    public void studentdetails(String Name,String Mail,String Advisor,String Semester,String Acayear,String Program,String Stuphone,String Guardphone,String Guardemail,String ungradedcourses, String coursesresolu, String problemcourses, String Otherprob){
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues values= new ContentValues();
        values.put(stuname,Name);
        values.put(mail,Mail);
        values.put(advisor,Advisor);
        values.put(semester,Semester);
        values.put(acayear,Acayear);
        values.put(program,Program);
        values.put(stuphone,Stuphone);
        values.put(guardphone, Guardphone);
        values.put(guardemail, Guardemail);
        values.put(ungraded, ungradedcourses);
        values.put(resolution, coursesresolu);
        values.put(probcourses, problemcourses);
        values.put(otherprob, Otherprob);
          db.insert(ThirdTable,null,values);
        db.close();
    }
    // this code searhes for the login credentials in the data database
    public String searchpass(String Userid ){
        SQLiteDatabase db= this.getReadableDatabase();
        String state="select Userid, Password from login_table ";
        Cursor cursor=db.rawQuery(state,null);
        String a,b;
        b="not found";
        if(cursor.moveToFirst()){
            do{
                a=cursor.getString(0);

                if(a.equals(Userid)){
                    b=cursor.getString(1);
                    break;
                }
            }
            while(cursor.moveToNext());
        }
        return b;
    }

public String searchlecpass(String Name){
    SQLiteDatabase db= this.getReadableDatabase();
    String state="Select Name, Password from Lect_login";
    Cursor cursor=db.rawQuery(state,null);
    String a,b;
    b="not found";
    if(cursor.moveToFirst()){
        do{
            a=cursor.getString(0);
            if(a.equals(Name)){
                b=cursor.getString(1);
                break;
            }
        }
        while(cursor.moveToNext());
    }
    return b;
}

/*
    public void getData(String usertype){
        SQLiteDatabase db=this.getWritableDatabase();
        String query="select Userid, Password from  login_table where Usertype=?";

        SQLiteStatement statement=db.compileStatement(query);
        statement.clearBindings();
        statement.bindString(6,usertype);

        statement.execute();
        db.close();
    }
    */


    }

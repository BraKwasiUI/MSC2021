package com.obeng3146.advise;

/**
 * Created by Oheneba k.b on 12/27/2017.
 */

public class User {

    private String studentid;
    private Double GPA;
    private String Password;

    public User() {

    }

    public User(String studentid, Double GPA, String password) {
        this.studentid = studentid;
        this.GPA = GPA;
        Password = password;
    }

    public String getStudentid() {
        return studentid;
    }

    public void setStudentid(String studentid) {
        this.studentid = studentid;
    }

    public Double getGPA() {
        return GPA;
    }

    public void setGPA(Double GPA) {
        this.GPA = GPA;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }
}

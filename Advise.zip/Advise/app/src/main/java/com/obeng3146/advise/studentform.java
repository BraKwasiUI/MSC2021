package com.obeng3146.advise;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;

import static com.obeng3146.advise.R.id.SPtxt;
import static com.obeng3146.advise.R.id.stumail;
import static com.obeng3146.advise.R.id.ungradedcourses;


public class studentform extends AppCompatActivity {

    private Spinner advisor,semester,acayear,program ;
    private EditText stuphone,guardphone,guardemail,Studentname,studentmail;
    private RadioGroup group1, group2,group3,group4;
    private RadioButton  rbtYesUngraded,rbtNoUngraded,rbtyesunresolved,rbtnounresolved,rbtyesproblems,rbtnoproblems,rbtyesotherproblems,rbtnootherproblesm;
    private EditText tilungradedcourses,tilcoursesgrades,tilenterproblems,tilenterotherprob;
    private Button scholarupload,btnsubmit;
    private TextView txtview2 ,secret,nameofFile;
    private int split, split2,split3,split4;
    private static int FILE_SELECT_CODE=1;
    DataBaseHelper myDb;// Setting the instance of the database in the activity_main java class

    private String academicyearinput;
    private String semesterinput;
    private  String programinput;
    private TextInputLayout tilungraded,tilgrades,tilproblems,tilprob;

    //This is for firebase
    private FirebaseDatabase database;
    private DatabaseReference myref;
    private FirebaseAuth myauth;
    private FirebaseAuth.AuthStateListener  myauthlistener;

    private StorageReference mStorageRef;

    private Uri mFileUri=null;

    private String advisorinput;
    String secrettxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studentform);

        //carrying the value
        secret=(TextView)findViewById(R.id.userid) ;
        Intent stextview= getIntent();
        secrettxt= stextview.getStringExtra("Username");
        secret.setText(secrettxt);


        database = FirebaseDatabase.getInstance();
        myref = database.getReference().child("Student");

        mStorageRef = FirebaseStorage.getInstance().getReference();

        myauth = FirebaseAuth.getInstance();
        myauthlistener= new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {



            }
        };

        myDb=new DataBaseHelper(this);


        //=========================Finding the edittext
        Studentname=(EditText)findViewById(R.id.stuname);
        studentmail=(EditText)findViewById(R.id.stumail);
        stuphone = (EditText) findViewById(R.id.SPtxt);
        guardphone = (EditText) findViewById(R.id.ParentPtxt);
        guardemail = (EditText) findViewById(R.id.Pmailtxt);
        //=============================================

        //========================================Finding the radiogroup
        group1 = (RadioGroup) findViewById(R.id.radioG1);
        group2 = (RadioGroup) findViewById(R.id.radioG2);
        group3 = (RadioGroup) findViewById(R.id.radioG3);
        group4=(RadioGroup)findViewById(R.id.radioG4);
        //======================================================

        nameofFile=(TextView)findViewById(R.id.filename) ;

        //=================================finding the radiobutton
        rbtYesUngraded = (RadioButton) findViewById(R.id.YesUngraded);
        rbtNoUngraded = (RadioButton) findViewById(R.id.NoUngraded);
        rbtyesunresolved = (RadioButton) findViewById(R.id.YesUnresolved);
        rbtnounresolved = (RadioButton) findViewById(R.id.NoUnresolved);
        rbtyesproblems = (RadioButton) findViewById(R.id.YesProblems);
        rbtnoproblems = (RadioButton) findViewById(R.id.NoProblems);
        rbtyesotherproblems = (RadioButton) findViewById(R.id.YesOtherProblems);
        rbtnootherproblesm = (RadioButton) findViewById(R.id.NoOtherProblems);
        //==================================================================

        //================================finding the textinputlayout
        tilungradedcourses = ((TextInputLayout) findViewById(R.id.ungradedtxt)).getEditText();
        tilcoursesgrades = ((TextInputLayout) findViewById(R.id.unresolvedtxt)).getEditText();
        tilenterproblems = ((TextInputLayout) findViewById(R.id.Problemstxt)).getEditText();
        tilenterotherprob = ((TextInputLayout) findViewById(R.id.OtherProblemstxt)).getEditText();

        tilungraded= (TextInputLayout) findViewById(R.id.ungradedtxt);
        tilgrades = (TextInputLayout) findViewById(R.id.unresolvedtxt);
        tilproblems = (TextInputLayout) findViewById(R.id.Problemstxt);
        tilprob = (TextInputLayout) findViewById(R.id.OtherProblemstxt);
        //================================================================

        //==============================finding the button
        scholarupload = (Button) findViewById(R.id.uploadbtn);
        btnsubmit = (Button) findViewById(R.id.submitbtn);
        //==================================================

// this is to make the visible the ungrades appear and disapper
        group1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {

                switch(checkedId){
                    case  R.id.YesUngraded:
                        tilungraded.setVisibility(View.VISIBLE);
                        break;
                    case R.id.NoUngraded:
                        tilungraded.setVisibility(View.INVISIBLE);
                }
            }
        });
//======================================================================group2
        group2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {

                switch(checkedId){
                    case  R.id.YesUnresolved:
                        tilgrades.setVisibility(View.VISIBLE);
                        break;
                    case R.id.NoUnresolved:
                        tilgrades.setVisibility(View.INVISIBLE);
                }
            }
        });
        //===============================================================group3
        group3.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {

                switch(checkedId){
                    case  R.id.YesProblems:

                        tilproblems.setVisibility(View.VISIBLE);
                        break;
                    case R.id.NoProblems:
                        tilproblems.setVisibility(View.INVISIBLE);
                }
            }
        });
        //========================================================================group4
        group4.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {

                switch(checkedId){
                    case  R.id.YesOtherProblems:
                        tilprob.setVisibility(View.VISIBLE);
                        break;
                    case R.id.NoOtherProblems:
                        tilprob.setVisibility(View.INVISIBLE);
                }
            }
        });



        //====================Advisor Spinner Begins here
        advisor=(Spinner) findViewById(R.id.advisorList);
        //create array adapter for the spinner
        ArrayAdapter<CharSequence> adapter =ArrayAdapter.createFromResource(this, R.array.Supervisors, android.R.layout.simple_spinner_item);
        //set the layout for the dropdown spinner
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //set the adapter for the Spinner
        advisor.setAdapter(adapter);
        //Code that gets the position of the slected item
        int postion=advisor.getSelectedItemPosition();
        //The code that selects the item
        advisor.setSelection(postion);//selects the first item


        advisor.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                split=position+1;

                //Sets the value chosen in the spinner to the text===================================================================
                advisorinput=(String) advisor.getSelectedItem();//this is very important to get the value to be played in the database
                //==================================================================================================================================
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
//====================================================================advisor Spinner Begins here


        //==================== Semester Spinner Begins here
        semester=(Spinner) findViewById(R.id.semesterList);
        //create array adapter for the spinner
        ArrayAdapter<CharSequence> adapter2 =ArrayAdapter.createFromResource(this, R.array.Semesters, android.R.layout.simple_spinner_item);
        //set the layout for the dropdown spinner
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //set the adapter for the Spinner
        semester.setAdapter(adapter2);
        //Code that gets the position of the slected item
         int getpostion=semester.getSelectedItemPosition();
        //The code that selects the item
        semester.setSelection(getpostion);//selects the first item


        semester.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                split2=position+1;
                //Sets the value chosen in the spinner to the text===================================================================
                semesterinput=(String) semester.getSelectedItem();//this is very important to get the value to be played in the database
                //==================================================================================================================================
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
//====================================================================advisor Spinner Begins here



        //==================== Academic year Spinner Begins here
        acayear =(Spinner) findViewById(R.id.academicList);
        //create array adapter for the spinner
        ArrayAdapter<CharSequence> adapter3 =ArrayAdapter.createFromResource(this, R.array.academic_years, android.R.layout.simple_spinner_item);
        //set the layout for the dropdown spinner
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //set the adapter for the Spinner
        acayear.setAdapter(adapter3);
        //Code that gets the position of the slected item
         int getpostion1=acayear.getSelectedItemPosition();
        //The code that selects the item
        acayear.setSelection(getpostion1);//selects the first item

        //Sets the value chosen in the spinner to the text===================================================================
        //==================================================================================================================================
        acayear.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                split3 =position+1;
                academicyearinput=(String) acayear.getSelectedItem();//this is very important to get the value to be played in the database

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
//====================================================================advisor Spinner Begins here



        //==================== Academic year Spinner Begins here
        program = (Spinner) findViewById(R.id.programlist);
        //create array adapter for the spinner
        ArrayAdapter<CharSequence> adapter4 =ArrayAdapter.createFromResource(this, R.array.programs, android.R.layout.simple_spinner_item);
        //set the layout for the dropdown spinner
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //set the adapter for the Spinner
        program.setAdapter(adapter4);
        //Code that gets the position of the slected item
         int getpostion2=program.getSelectedItemPosition();
        //The code that selects the item
        program.setSelection(getpostion2);//selects the first item


        program.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                split4=position+1;
                programinput=(String) program.getSelectedItem();//this is very important to get the value to be played in the database
                //==================================================================================================================================
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
//====================================================================advisor Spinner Begins here



        btnsubmit.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View v) {

                switch (v.getId()) {
                    case R.id.submitbtn:
                        final String Name= Studentname.getText().toString().trim();
                        final String Studentmail=studentmail.getText().toString().trim();
                        final String studentphone = stuphone.getText().toString().trim();
                        final String guardianphone=guardphone.getText().toString().trim();
                        final String guardianemail= guardemail.getText().toString().trim();
                        final String Ungradedcourses=tilungradedcourses.getText().toString().trim();
                        final String resolution= tilcoursesgrades.getText().toString().trim();
                        final String problemcourses=tilenterproblems.getText().toString().trim();
                        final String otherproblems=tilenterotherprob.getText().toString().trim();


                           if (Name.isEmpty() && Studentmail.isEmpty() && guardianemail.isEmpty()){

                               Toast.makeText(getApplicationContext(),"Fields are required!!", Toast.LENGTH_SHORT).show();
                       }
                       else if(mFileUri==null){
                               Toast.makeText(getApplicationContext(),"Please select a file!!", Toast.LENGTH_SHORT).show();
                    }
                        else{
                               StorageReference riverSef=mStorageRef.child("file").child(mFileUri.getLastPathSegment());

                               riverSef.putFile(mFileUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                   @Override
                                   public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                       final Uri downloadUri=taskSnapshot.getDownloadUrl();

                                       final Student thestudent= new Student(
                                               secret.getText().toString()
                                               ,Name
                                               ,Studentmail
                                               ,advisorinput
                                               ,semesterinput
                                               ,academicyearinput
                                               , programinput
                                               ,studentphone
                                               ,guardianphone
                                               ,guardianemail
                                               ,Ungradedcourses
                                               ,resolution
                                               ,problemcourses
                                               ,otherproblems
                                               ,downloadUri.toString());

                                       myref.child(thestudent.getThesecret()).setValue(thestudent).addOnCompleteListener(new OnCompleteListener<Void>() {
                                           @Override
                                           public void onComplete(@NonNull Task<Void> task) {
                                               if(task.isSuccessful()){
                                                   Toast.makeText(studentform.this, "Submitted successfully", Toast.LENGTH_SHORT).show();

                                                     Intent i = new Intent(studentform.this, closepaged.class);
                                                   startActivity(i);

//
                                               }
                                               else{
                                                   Toast.makeText(studentform.this, "Submission unsuccessful", Toast.LENGTH_SHORT).show();
                                               }
                                           }
                                       });

                                   }
                               });
                              // myDb.studentdetails(Name.trim(),Studentmail.trim(),advisorinput.trim(), semesterinput.trim(),academicyearinput.trim(),programinput.trim(),studentphone.trim(),guardianphone.trim(),guardianemail.trim(),Ungradedcourses.trim(),resolution.trim(),problemcourses.trim(),otherproblems.trim());
                               //Toast.makeText(getApplicationContext(),"submission Sucessfully", Toast.LENGTH_SHORT).show();


                           }


                }

            }
        });

        scholarupload.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent= new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);

                try {
                    startActivityForResult(
                            Intent.createChooser(intent, "File selected"), FILE_SELECT_CODE);
                }catch (android.content.ActivityNotFoundException ex){
                    Toast.makeText(studentform.this, "Please download filemanager", Toast.LENGTH_SHORT).show();
                }

            }
        });

        checkUserExistence();

    }

    private void checkUserExistence(){
        myref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild(secrettxt)){
                    Intent i = new Intent(studentform.this, Doublelogin.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                     startActivity(i);
                    finish();
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    protected void onActivityResult(int requestCode, int resusltCode, Intent data){
        if (requestCode==FILE_SELECT_CODE && resusltCode== RESULT_OK){
             mFileUri= data.getData();


            String uriString= mFileUri.toString();
            File myFile=new File(uriString);
            // String path= myFile.getAbsolutePath();

            String displayName= null;

            if(uriString.startsWith("content://")){
                Cursor cursor=null;
                try{
                    cursor= studentform.this.getContentResolver().query(mFileUri,null,null,null,null);
                    if(cursor!=null&&cursor.moveToFirst()){
                        displayName=cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                    }

                }finally{
                    cursor.close();
                }
            }else if (uriString.startsWith("file://")){
                displayName=myFile.getName();
            }



            // Toast.makeText(this,"You have Selected a File", Toast.LENGTH_SHORT).show();


            nameofFile.setText(displayName);
        }
        super.onActivityResult(requestCode,resusltCode,data);
    }


}

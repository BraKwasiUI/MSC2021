package com.obeng3146.advise;

/**
 * Created by Oheneba k.b on 12/27/2017.
 */

public class Advisors {
    private String advisorid;
    private String password;

    public Advisors() {
    }

    public Advisors(String advisorid, String password) {
        this.advisorid = advisorid;
        this.password = password;
    }

    public String getAdvisorid() {
        return advisorid;
    }

    public void setAdvisorid(String advisorid) {
        this.advisorid = advisorid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

package com.obeng3146.advise;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements  View.OnClickListener {
private TextView studentlog;
//private TextView adminlog;
    private TextView advisorlog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        studentlog=(TextView) findViewById(R.id.studentOption);
        studentlog.setOnClickListener(this);

//        adminlog=(TextView) findViewById(R.id.adminOption);
//        adminlog.setOnClickListener(this);

        advisorlog=(TextView) findViewById(R.id.advisorOption);
        advisorlog.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.studentOption:
              startActivity( new Intent(MainActivity.this,studentlogin.class));
                break;
//
//            case R.id.adminOption:
//                startActivity( new Intent(MainActivity.this,loginAdmin.class));
//                break;

            case R.id.advisorOption:
                startActivity( new Intent(MainActivity.this,advisorLogin.class));
                break;


        }
    }
}
